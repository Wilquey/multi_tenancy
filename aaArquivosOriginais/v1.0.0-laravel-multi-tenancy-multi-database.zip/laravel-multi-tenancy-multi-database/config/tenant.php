<?php

return [
    'domain_main' => 'curso-laravel-multi-tenancy.local',
];