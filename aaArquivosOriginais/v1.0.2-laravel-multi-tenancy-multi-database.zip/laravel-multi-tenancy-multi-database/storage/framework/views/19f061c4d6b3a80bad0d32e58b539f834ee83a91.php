

<?php $__env->startSection('content'); ?>

<h1>
    Empresas
    <a href="<?php echo e(route('company.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus-square"></i>
    </a>
</h1>

<?php echo $__env->make('tenants.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<ul class="media-list">
    <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li class="media">
        <div class="media-body">
            <span class="text-muted pull-right">
                <small class="text-muted"><?php echo e($company->created_at->format('d/m/Y')); ?></small>
            </span>
            <strong class="text-success"><?php echo e($company->domain); ?></strong>
            <p>
                <?php echo e($company->name); ?>

                <br>
                <a href="<?php echo e(route('company.show', $company->domain)); ?>">Detalhes</a> |
                <a href="<?php echo e(route('company.edit', $company->domain)); ?>">Editar</a>
            </p>
        </div>
    </li>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li class="media">
        <p>Nenhuma empresa cadastrada!</p>
    </li>
    <?php endif; ?>

    <?php echo $companies->links(); ?>

</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tenants.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>