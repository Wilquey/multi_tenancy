

<?php $__env->startSection('content'); ?>

<h1>Detalhes da empresa <b><?php echo e($company->name); ?></b></h1>

<ul>
    <li><strong>Nome:</strong> <?php echo e($company->name); ?></li>
    <li><strong>Domínio:</strong> <?php echo e($company->domain); ?></li>
    <li><strong>Database:</strong> <?php echo e($company->bd_database); ?></li>
    <li><strong>Host:</strong> <?php echo e($company->bd_hostname); ?></li>
    <li><strong>Usuário:</strong> <?php echo e($company->bd_username); ?></li>
    <li><strong>Senha:</strong></li>
</ul>

<hr>

<form action="<?php echo e(route('company.destroy', $company->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="_method" value="DELETE">

    <button type="submit" class="btn btn-danger">Deletar Empresa: <?php echo e($company->name); ?></button>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('tenants.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>