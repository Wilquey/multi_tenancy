

<?php $__env->startSection('content'); ?>

<h1>Recursos de tenants</h1>

<a href="<?php echo e(route('company.index')); ?>">
    <img src="<?php echo e(asset('imgs/companies.png')); ?>" alt="Empresas">
</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tenants.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>