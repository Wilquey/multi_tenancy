

<?php $__env->startSection('content'); ?>

<h1>Detalhes da empresa <b><?php echo e($company->name); ?></b></h1>

<form action="<?php echo e(route('company.update', $company->id)); ?>" method="post">
    <input type="hidden" name="_method" value="PUT">

    <?php echo $__env->make('tenants.companies._partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tenants.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>