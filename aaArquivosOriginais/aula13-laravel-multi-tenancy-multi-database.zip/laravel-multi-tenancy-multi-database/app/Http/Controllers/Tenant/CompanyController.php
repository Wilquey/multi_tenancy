<?php

namespace App\Http\Controllers\Tenant;

use App\Events\Tenant\DatabaseCreated;
use App\Models\Company;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Events\Tenant\CompanyCreated;

class CompanyController extends Controller
{
    private $company;

    public function __construct(Company $company)
    {
        $this->company = $company;
    }

    public function store(Request $request)
    {
        $company = $this->company->create([
            'name'          => 'Empresa x ' . str_random(5),
            'domain'        => str_random(5) . 'minhaempresa.com',
            'bd_database'   => 'multi_tenant_default',
            'bd_hostname'   => 'mysql',
            'bd_username'   => 'root',
            'bd_password'   => 'root',
        ]);

        if (true)
            event(new CompanyCreated($company));
        else
            event(new DatabaseCreated($company));

        dd($company);
    }
}
