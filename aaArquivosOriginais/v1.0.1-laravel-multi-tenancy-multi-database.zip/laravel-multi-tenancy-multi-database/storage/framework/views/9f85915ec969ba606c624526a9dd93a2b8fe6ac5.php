

<?php $__env->startSection('content'); ?>

<h1>Cadastrar nova empresa</h1>

<form action="<?php echo e(route('company.store')); ?>" method="post">
    <?php echo $__env->make('tenants.companies._partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tenants.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>