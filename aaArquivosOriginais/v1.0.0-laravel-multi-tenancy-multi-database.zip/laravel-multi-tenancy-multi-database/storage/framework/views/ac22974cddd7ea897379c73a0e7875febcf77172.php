<?php echo $__env->make('tenants.includes.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo csrf_field(); ?>

<div class="form-group">
    <input value="<?php echo e(isset($company->name) ? $company->name : old('name')); ?>" class="form-control" type="text" name="name" placeholder="Nome:">
</div>
<div class="form-group">
    <input value="<?php echo e(isset($company->domain) ? $company->domain : old('domain')); ?>" class="form-control" type="text" name="domain" placeholder="Domínio:">
</div>
<div class="form-group">
    <input value="<?php echo e(isset($company->bd_database) ? $company->bd_database : old('bd_database')); ?>" class="form-control" type="text" name="bd_database" placeholder="Database:">
</div>
<div class="form-group">
    <input value="<?php echo e(isset($company->bd_hostname) ? $company->bd_hostname : old('bd_hostname')); ?>" class="form-control" type="text" name="bd_hostname" placeholder="Host:">
</div>
<div class="form-group">
    <input value="<?php echo e(isset($company->bd_username) ? $company->bd_username : old('bd_username')); ?>" class="form-control" type="text" name="bd_username" placeholder="Usuário:">
</div>
<div class="form-group">
    <input value="<?php echo e(isset($company->bd_password) ? $company->bd_password : old('bd_password')); ?>" class="form-control" type="password" name="bd_password" placeholder="Senha:">
</div>

<?php if(!isset($company)): ?>
<div class="form-group">
    <label for="create_database">
        <input type="checkbox" name="create_database" checked>
        Criar banco de dados?
    </label>
</div>
<?php endif; ?>

<div class="form-group">
    <button type="submit" class="btn btn-success">Enviar</button>
</div>